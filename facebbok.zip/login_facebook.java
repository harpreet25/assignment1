import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class login_facebook {
	
	public void login()
	{
		
	
		System.setProperty("webdriver.gecko.driver", "D:\\selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com");
	
		driver.findElement(By.id("email")).sendKeys("dasharivallabh@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("s76637663S");
		
		driver.findElement(By.id("u_0_p")).click();
		
		
		
	}
	
	public static void main(String[] args) {
		
		
		
		login_facebook ab= new login_facebook();
		ab.login();
		
		
		
	}
		
		
	}


