import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class facebook_signup {
	
	public static void main(String[] args) {
		
		String url=System.getProperty("user.dir")+"\\src\\geckodriver.exe";
		System.out.println(url);
		
		System.setProperty("webdriver.gecko.driver", url);
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/");
		
		driver.findElement(By.id("u_0_1")).sendKeys("Myproject");
		driver.findElement(By.id("u_0_3")).sendKeys("test");
		driver.findElement(By.id("u_0_6")).sendKeys("dasharivallabh@gmail.com");
		driver.findElement(By.id("u_0_9")).sendKeys("dasharivallabh@gmail.com");
		driver.findElement(By.id("u_0_c")).sendKeys("s76637663S");

		driver.findElement(By.id("day")).sendKeys("5");
		driver.findElement(By.id("month")).sendKeys("Feb");
		driver.findElement(By.id("year")).sendKeys("1990");
		driver.findElement(By.id("u_0_k")).click();
		driver.findElement(By.id("u_0_g")).click();
		
		
		
	}

}
